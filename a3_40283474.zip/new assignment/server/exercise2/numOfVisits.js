// EXERCISE 2
const express = require('express');
const cookieParser = require('cookie-parser')
const app = express();
const port = 3000;

app.use(cookieParser());

// Function to get time and date
function getTimeDate() {
    const now = new Date();
    const options = {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        timeZoneName: 'short',
        year: 'numeric'
    };
    return now.toLocaleString('en-US', options);
}

// Define route for the node.js page
app.get('/', (req, res) => {
    let visits = parseInt(req.cookies.visits) || 0;

    if (visits === 0) {
        // First time visiting webpage
        res.cookie('visits', ++visits);
        res.cookie('lastVisitTime', getTimeDate());
        res.send("Welcome to my webpage! It is your first time that you are here.");
    } else {
        // If user has already visited before
        res.cookie('visits', ++visits);
        const lastVisitTime = req.cookies.lastVisitTime || 'Unknown';
        const dateTime = getTimeDate();
        res.cookie('lastVisitTime', dateTime);
        res.send(`Hello, this is the ${visits} time that you are visiting my webpage.<br><i><b>Last time you visited my webpage on: ${lastVisitTime}</b></i>`)
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});