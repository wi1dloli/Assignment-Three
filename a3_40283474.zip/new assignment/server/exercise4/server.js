const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs');
const session = require('express-session');

const app = express();
const port = 3000;

// Set EJS as template engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware to parse request bodies
app.use(bodyParser.urlencoded({ extended: false }));

// Middleware for session management
app.use(session({
    secret: 'n$g^H5@r#sDvKu8Tf&3wAq*yZ7x!LmP',
    resave: false,
    saveUninitialized: true
}));

// Serve static files from the exercise4 directory
app.use(express.static(path.join(__dirname)));

// Route for serving the homepage
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Route for serving the donate page
app.get('/donate', (req, res) => {
    // Check if user is logged in
    if (!req.session || !req.session.loggedIn) {
        // If the user is not logged in, redirect them to the login page
        return res.redirect('/login.html');
    }

    // If the user is logged in, serve the donate.html page
    res.sendFile(path.join(__dirname, 'donate.html'));
});

// Route for handling the login form submission
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Read login file
    fs.readFile('login.txt', 'utf8', (err, data) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Internal Server Error');
        }

        // Split data into lines and loop through each line
        const lines = data.split('\n');
        let loginSuccess = false; // Flag to track login success
        for (let i = 0; i < lines.length; i++) {
            // Split each line into username and password
            const [storedUsername, storedPassword] = lines[i].split(':');

            // Check if provided username and password match
            if (storedUsername === username && storedPassword === password) {
                // Set up a session to indicate that the user is logged in
                req.session.loggedIn = true;
                req.session.username = username; // Store username in session
                loginSuccess = true; // Set login success flag to true
                // Redirect the user back to the donate.html page after successful login
                return res.redirect('/donate');
            }
        }

        // If no match is found, send back a login failed message
        res.send('Login failed. Please try again.<a href="login.html"> Return to previous page</a>');
    });
});

// Route for serving the create account page
app.get('/createAccount', (req, res) => {
    res.sendFile(path.join(__dirname, 'createaccount.html'));
});

// Route for handling account creation form submission
app.post('/createAccount', (req, res) => {
    const { username, password } = req.body;

    // Check if username and password satisfy the format criteria
    const usernameRegex = /^[a-zA-Z0-9]+$/;
    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{4,}$/;

    if (!usernameRegex.test(username)) {
        return res.send('Invalid username format. Username can contain letters (both upper and lower case) and digits only.<a href="createaccount.html"> Return to account creation page</a>');
    }

    if (!passwordRegex.test(password)) {
        return res.send('Invalid password format. Password must be at least 4 characters long and contain at least one letter and one digit.<br><a href="createaccount.html">Return to account creation page</a>');
    }

    // Read login file
    fs.readFile('login.txt', 'utf8', (err, data) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Internal Server Error');
        }

        // Check if username already exists
        const usernames = data.split('\n').map(line => line.split(':')[0]);
        if (usernames.includes(username)) {
            return res.send('Username already exists. Please choose another. <a href="createaccount.html">Return to account creation page</a>');
        }

        // Write new account to login file
        fs.appendFile('login.txt', `${username}:${password}\n`, 'utf8', err => {
            if (err) {
                console.error(err);
                return res.status(500).send('Internal Server Error');
            }

            res.send('Account created successfully! You can now login. <a href="index.html">Return to homepage</a>');
        });
    });
});

// Route for handling pet submission form submission
app.post('/giveAwayPet', (req, res) => {
    const { petType, breed, age, gender, otherDogs, otherCats, smallChildren, comments, ownerName, ownerEmail } = req.body;

    // Validate the submitted data
    if (!petType || !breed || !age || !gender || !ownerName || !ownerEmail) {
        return res.status(400).send('All fields are required');
    }

    // Check if the file exists and get its content
    fs.readFile('availablePets.txt', 'utf8', (err, data) => {
        if (err && err.code !== 'ENOENT') {
            console.error(err);
            return res.status(500).send('Internal Server Error');
        }

        let count = 1; // Start count from 1 for the first entry
        // If the file exists, count the existing entries
        if (data) {
            const lines = data.trim().split('\n');
            count = lines.length + 1;
        }

        // Format the pet information
        const petInfo = `${count}:${req.session.username}:${petType}:${breed}:${age}:${gender}:${otherDogs ? 'otherDogs' : ''}:${otherCats ? 'otherCats' : ''}:${smallChildren ? 'smallChildren' : ''}:${comments}:${ownerName}:${ownerEmail}`;

        // Append the pet information to the available pet information file
        fs.appendFile('availablePets.txt', petInfo + '\n', (err) => {
            if (err) {
                console.error(err);
                return res.status(500).send('Internal Server Error');
            }
            res.send('Pet information submitted successfully');
        });
    });
});

// Route for handling pet search
app.post('/searchPets', (req, res) => {
    // Retrieve search criteria from the request body
    const { petType, breed, age, gender, compatibilityDogs, compatibilityCats, compatibilityChildren } = req.body;

    // Construct the search query
    const searchQuery = {
        petType: petType,
        breed: breed,
        age: age,
        gender: gender,
        compatibilities: [compatibilityDogs, compatibilityCats, compatibilityChildren].filter(Boolean) // Filter out unchecked compatibilities
    };
    // Split the compatibility string into an array
    const compatibilityArray = searchQuery.compatibilities;

    // Read the available pets file and filter based on the search criteria
    fs.readFile('availablePets.txt', 'utf8', (err, data) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Internal Server Error');
        }

        // Split the file data into lines and filter based on the search criteria
        const pets = data.trim().split('\n').map(line => {
            const petData = line.split(':');
            const ownerNameIndex = petData.length - 2;
            const ownerEmailIndex = petData.length - 1;
            return {
                petType: petData[2],
                breed: petData[3],
                age: petData[4],
                gender: petData[5],
                compatibilities: petData.slice(6, ownerNameIndex),
                comments: petData[ownerNameIndex],
                ownerName: petData[ownerNameIndex],
                ownerEmail: petData[ownerEmailIndex]
            };
        }).filter(pet => {
            return (
                (petType === 'any' || pet.petType === petType) &&
                (breed === '' || pet.breed.toLowerCase().includes(breed.toLowerCase())) &&
                (age === 'any' || pet.age === age) &&
                (gender === 'any' || pet.gender === gender) &&
                compatibilityArray.every(compatibility => pet.compatibilities.includes(compatibility))
            );
        });

        // Render the search results using EJS and pass the data
        res.render('search_result', { pets: pets });
    });
});

// Route for handling the logout request
app.post('/logout', (req, res) => {
    // Perform any necessary logout operations, such as clearing session data
    // For example, if you're using sessions, you can destroy the session
    req.session.destroy((err) => {
        if (err) {
            console.error('Error destroying session:', err);
            // Handle error, if necessary
            return res.status(500).send('Internal Server Error');
        }
        // Redirect the user to a confirmation page or any other page
        res.send("You've successfully logged out.");
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is listening at http://localhost:${port}`);
});