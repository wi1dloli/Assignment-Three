// phoneCheck.js
const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Middleware to parse request bodies
app.use(bodyParser.urlencoded({ extended: false }));

// Route for serving the HTML form
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/form.html');
});

// Route for handling form submission and checking phone number format
app.post('/checkPhoneNumber', (req, res) => {
    const { name, phoneNumber } = req.body;
    const phoneNumberPattern = /^[0-9]{3}-[0-9]{3}-[0-9]{4}$/;

    if (phoneNumberPattern.test(phoneNumber)) {
        res.send(`${name}, the phone number (${phoneNumber}) is correct.`);
    } else {
        res.send(`${name}, the phone number (${phoneNumber}) is incorrect. Please use the format xxx-xxx-xxxx.`);
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server is listening at http://localhost:${port}`);
});
