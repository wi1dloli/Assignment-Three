function uppercaseFirstandLast(str) {
    // Check if the input string is undefined
    if (str === undefined) {
        return "String is undefined";
    }

    // Split input into words
    const words = str.split(" ");

    const modifiedWords = words.map(word => {
        // Capitalize letters
        const firstLetter = word.charAt(0).toUpperCase();
        const lastLetter = word.charAt(word.length - 1).toUpperCase();

        // Return modified word
        return firstLetter + word.slice(1, -1) + lastLetter;
    });

    // Combine all the words
    const modifiedStr = modifiedWords.join(" ");

    // Return new string
    return modifiedStr;
}

// Export the uppercaseFirstandLast function
module.exports = uppercaseFirstandLast;
