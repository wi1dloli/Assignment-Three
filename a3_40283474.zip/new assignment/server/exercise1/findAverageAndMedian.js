function findAverageAndMedian (entries) {
    // Check if the input string is undefined
    if (entries === undefined) {
        return "Array entries are undefined";
    }

    // Calculate average
    const average = entries.reduce((total, num) => total + num, 0) / entries.length;

    // Calculate median
    const sortedNumbers = entries.slice().sort((a, b) => a - b);
    const middleIndex = Math.floor(sortedNumbers.length / 2);
    const median = sortedNumbers.length % 2 === 0 ? (sortedNumbers[middleIndex - 1] + sortedNumbers[middleIndex]) / 2 : sortedNumbers[middleIndex];

    // Return average and median
    return "Average: " + average + ", Median: " + median;
}

// Export the findAverageAndMedian function
module.exports = findAverageAndMedian;