const express = require('express');
const app = express();
const port = 3000;

// Import functions
const findSummation = require('./findSummation');
const uppercaseFirstandLast = require('./uppercaseFirstandLast');
const findAverageAndMedian = require('./findAverageAndMedian.js');
const find4Digits = require('./find4Digits')

// Define route for the /findSummation endpoint
app.get('/findSummation', (req, res) => {
    // Parse input from request
    const N = req.query.N ? parseInt(req.query.N) : 1;
    const answer = findSummation(N);

    // Print answer
    if (answer === false) {
        res.send("The number input is invalid. (Not a positive integer)");
    } else {
        res.send(`The sum of numbers from 1 to ${N} is: ${answer}.`);
    }
});

// Define route for /uppercaseFirstandLast endpoint
app.get('/uppercaseFirstandLast', (req, res) => {
    const str = req.query.str;
    const newString = uppercaseFirstandLast(str);

    // Print newString
    res.send(newString);
})

// Define route for the /findAverageAndMedian endpoint
app.get('/findAverageAndMedian', (req, res) => {
    // Get the entries parameter from the query string
    const entriesString = req.query.entries;
    const entries = entriesString.split(' ').map(Number);
    const result = findAverageAndMedian(entries);

    // Print average and median
    res.send(result);
});

// Define route for the /find4Digits endpoint
app.get('/find4Digits', (req, res) => {
    // Get the numbers parameter from the query string
    const numbersString = req.query.numbers;

    // Call the find4Digits function with the numbers string
    const firstFourDigits = find4Digits(numbersString);

    // Print the first four-digit number
    res.send(firstFourDigits);
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
