
function findSummation (N = 1) {
    // Check if N is a positive integer
    if (typeof N !== 'number' || N <= 0 || !Number.isInteger(N)) {
        return false;
    }

    // Calculate the summation from 1 to N
    let sum = 0;
    for (let i = 1; i <= N; i++) {
        sum += i;
    }

    return sum;
}

// Export the findSummation function
module.exports = findSummation;
