function find4Digits(numbers) {
    // Check if the input string is undefined
    if (numbers === undefined) {
        return "No numbers defined.";
    }

    // Split input into array of numbers
    const numberArray = numbers.split(' ');

    // Find first four-digit number
    for (let i = 0; i < numberArray.length; i++) {
        const number = numberArray[i];
        // Check if the number is a string and has a length of 4
        if (typeof number === 'string' && number.length === 4) {
            return number; // Return the first four-digit number found
        }
    }

    // If no four-digit number is found, return false
    return "No four-digit number found.";
}

// Export the find4Digits function
module.exports = find4Digits;
